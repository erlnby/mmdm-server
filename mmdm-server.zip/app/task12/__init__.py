from .calc import solve12
from .models import Task12In, Task12Out
