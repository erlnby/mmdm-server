from .calc import solve6
from .models import Task6In, Task6Out
