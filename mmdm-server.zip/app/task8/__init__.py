from .calc import solve8
from .models import Task8In, Task8Out
