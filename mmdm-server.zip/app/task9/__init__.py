from .calc import solve9
from .models import Task9In, Task9Out
