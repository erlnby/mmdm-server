from .calc import solve10
from .models import Task10In, Task10Out
