from .calc import solve7
from .models import Task7In, Task7Out
